import { NodeBuilder, NodeFrame, TextureNode } from 'three/webgpu';
import { FilterNode } from './FilterNode';
import { Node } from './node';
export declare abstract class SeparableFilterNode extends FilterNode {
    iterations: number;
    private readonly horizontalRT;
    private readonly verticalRT;
    private readonly material;
    private readonly mesh;
    private rendererState?;
    protected readonly inputTexelSize: import('three/webgpu').UniformNode<import('three').Vector2>;
    protected readonly direction: import('three/webgpu').UniformNode<import('three').Vector2>;
    constructor(inputNode?: TextureNode | null);
    setSize(width: number, height: number): this;
    updateBefore({ renderer }: NodeFrame): void;
    protected abstract setupOutputNode(builder: NodeBuilder): Node;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
