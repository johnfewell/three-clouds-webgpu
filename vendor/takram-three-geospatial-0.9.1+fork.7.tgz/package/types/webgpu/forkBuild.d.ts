export declare const forkBuild: {
    readonly release: 7;
    readonly raySpheresIntersectionsLanes: 4;
    readonly r186Kernels: true;
};
