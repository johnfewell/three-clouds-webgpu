import { TempNode, NodeBuilder, NodeFrame, TextureNode } from 'three/webgpu';
export declare class LensHaloNode extends TempNode {
    static get type(): string;
    inputNode?: TextureNode | null;
    intensity: import('three/webgpu').UniformNode<number>;
    chromaticAberration: import('three/webgpu').UniformNode<number>;
    private readonly aspectRatio;
    constructor(inputNode?: TextureNode | null);
    updateBefore({ renderer }: NodeFrame): void;
    setup(builder: NodeBuilder): unknown;
}
