import { Vector3 } from 'three';
import { Ellipsoid } from './Ellipsoid';
import { ProjectOnEllipsoidSurfaceOptions } from './helpers/projectOnEllipsoidSurface';
export type GeodeticTuple = [number, number, number];
export interface GeodeticLike {
    readonly longitude: number;
    readonly latitude: number;
    readonly height: number;
}
export declare class Geodetic {
    longitude: number;
    latitude: number;
    height: number;
    static readonly MIN_LONGITUDE: number;
    static readonly MAX_LONGITUDE: number;
    static readonly MIN_LATITUDE: number;
    static readonly MAX_LATITUDE: number;
    constructor(longitude?: number, latitude?: number, height?: number);
    set(longitude: number, latitude: number, height?: number): this;
    clone(): Geodetic;
    copy(other: GeodeticLike): this;
    equals(other: GeodeticLike): boolean;
    setLongitude(value: number): this;
    setLatitude(value: number): this;
    setHeight(value: number): this;
    normalize(): this;
    setFromECEF(position: Vector3, options?: ProjectOnEllipsoidSurfaceOptions & {
        ellipsoid?: Ellipsoid;
    }): this;
    toECEF(result?: Vector3, options?: {
        ellipsoid?: Ellipsoid;
    }): Vector3;
    fromArray(array: readonly number[], offset?: number): this;
    toArray(array?: number[], offset?: number): number[];
    [Symbol.iterator](): Generator<number>;
}
