import { Loader, ColorSpace, Data3DTexture, DataTexture, LoadingManager, MagnificationTextureFilter, Mapping, MinificationTextureFilter, PixelFormat, TextureDataType, Wrapping } from 'three';
import { Class } from 'type-fest';
import { TypedArray } from './typedArray';
import { TypedArrayParser } from './typedArrayParsers';
export interface DataTextureLoaderOptions {
    width?: number;
    height?: number;
    depth?: number;
    mapping?: Mapping;
    wrapS?: Wrapping;
    wrapT?: Wrapping;
    wrapR?: Wrapping;
    magFilter?: MagnificationTextureFilter;
    minFilter?: MinificationTextureFilter;
    format?: PixelFormat;
    type?: TextureDataType;
    anisotropy?: number;
    colorSpace?: ColorSpace;
    manager?: LoadingManager;
}
export declare class DataTextureLoader<T extends DataTexture | Data3DTexture = DataTexture | Data3DTexture, U extends TypedArray = TypedArray> extends Loader<T> {
    textureClass: Class<T>;
    parser: TypedArrayParser<U>;
    options: DataTextureLoaderOptions;
    constructor(textureClass: Class<T>, parser: TypedArrayParser<U>, options?: DataTextureLoaderOptions, manager?: LoadingManager);
    load(url: string, onLoad?: (data: T) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): T;
}
