import { Matrix4, Vector3, Ray } from 'three';
import { ProjectOnEllipsoidSurfaceOptions } from './helpers/projectOnEllipsoidSurface';
export declare class Ellipsoid {
    static readonly WGS84: Ellipsoid;
    readonly radii: Vector3;
    constructor(x: number, y: number, z: number);
    get minimumRadius(): number;
    get maximumRadius(): number;
    get flattening(): number;
    get eccentricity(): number;
    get eccentricitySquared(): number;
    reciprocalRadii(result?: Vector3): Vector3;
    reciprocalRadiiSquared(result?: Vector3): Vector3;
    projectOnSurface(position: Vector3, result?: Vector3, options?: ProjectOnEllipsoidSurfaceOptions): Vector3 | undefined;
    getSurfaceNormal(position: Vector3, result?: Vector3): Vector3;
    getEastNorthUpVectors(position: Vector3, east?: Vector3, north?: Vector3, up?: Vector3): void;
    getEastNorthUpFrame(position: Vector3, result?: Matrix4): Matrix4;
    getNorthUpEastFrame(position: Vector3, result?: Matrix4): Matrix4;
    getIntersection(ray: Ray, result?: Vector3): Vector3 | undefined;
    getOsculatingSphereCenter(surfacePosition: Vector3, radius: number, result?: Vector3): Vector3;
    getNormalAtHorizon(position: Vector3, direction: Vector3, result?: Vector3): Vector3;
}
