import { Loader } from 'three';
export declare class ArrayBufferLoader extends Loader<ArrayBuffer> {
    load(url: string, onLoad: (data: ArrayBuffer) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): void;
}
