export type TileCoordinateTuple = [number, number, number];
export interface TileCoordinateLike {
    readonly x: number;
    readonly y: number;
    readonly z: number;
}
export declare class TileCoordinate {
    x: number;
    y: number;
    z: number;
    constructor(x?: number, y?: number, z?: number);
    set(x: number, y: number, z?: number): this;
    clone(): TileCoordinate;
    copy(other: TileCoordinateLike): this;
    equals(other: TileCoordinateLike): boolean;
    getParent(result?: TileCoordinate): TileCoordinate;
    traverseChildren(depth: number, result?: TileCoordinate): Generator<TileCoordinate>;
    fromArray(array: readonly number[], offset?: number): this;
    toArray(array?: number[], offset?: number): number[];
    [Symbol.iterator](): Generator<number>;
}
