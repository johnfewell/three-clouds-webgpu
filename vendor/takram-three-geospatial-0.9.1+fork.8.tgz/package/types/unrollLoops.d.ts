export declare function unrollLoops(string: string): string;
