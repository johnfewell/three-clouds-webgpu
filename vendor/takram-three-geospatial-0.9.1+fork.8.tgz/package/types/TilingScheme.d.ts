import { Vector2 } from 'three';
import { GeodeticLike } from './Geodetic';
import { Rectangle, RectangleLike } from './Rectangle';
import { TileCoordinate, TileCoordinateLike } from './TileCoordinate';
export interface TilingSchemeLike {
    readonly width: number;
    readonly height: number;
    readonly rectangle: RectangleLike;
}
export declare class TilingScheme {
    width: number;
    height: number;
    rectangle: Rectangle;
    constructor(width?: number, height?: number, rectangle?: Rectangle);
    clone(): TilingScheme;
    copy(other: TilingSchemeLike): this;
    getSize(z: number, result?: Vector2): Vector2;
    getTile(geodetic: GeodeticLike, z: number, result?: TileCoordinate): TileCoordinate;
    getRectangle(tile: TileCoordinateLike, result?: Rectangle): Rectangle;
}
