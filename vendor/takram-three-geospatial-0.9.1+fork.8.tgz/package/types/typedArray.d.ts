import { Float16Array, Float16ArrayConstructor } from '@petamoriken/float16';
export type TypedArray = Int8Array | Uint8Array | Uint8ClampedArray | Int16Array | Uint16Array | Int32Array | Uint32Array | Float16Array | Float32Array | Float64Array;
export type TypedArrayConstructor = Int8ArrayConstructor | Uint8ArrayConstructor | Uint8ClampedArrayConstructor | Int16ArrayConstructor | Uint16ArrayConstructor | Int32ArrayConstructor | Uint32ArrayConstructor | Float16ArrayConstructor | Float32ArrayConstructor | Float64ArrayConstructor;
export declare function isTypedArray(value: unknown): value is TypedArray;
export { Float16Array };
