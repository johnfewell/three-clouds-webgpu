interface MaterialLike {
    defines?: Record<string, unknown>;
    set needsUpdate(value: boolean);
}
interface EffectLike {
    defines: Map<string, unknown>;
}
export declare function define(name: string): <T extends MaterialLike | EffectLike, K extends keyof T>(target: T[K] extends boolean ? T : never, propertyKey: K) => void;
export interface DefineIntDecoratorOptions {
    min?: number;
    max?: number;
}
export declare function defineInt(name: string, { min, max }?: DefineIntDecoratorOptions): <T extends MaterialLike | EffectLike, K extends keyof T>(target: T[K] extends number ? T : never, propertyKey: K) => void;
export interface DefineFloatDecoratorOptions {
    min?: number;
    max?: number;
    precision?: number;
}
export declare function defineFloat(name: string, { min, max, precision }?: DefineFloatDecoratorOptions): <T extends MaterialLike | EffectLike, K extends keyof T>(target: T[K] extends number ? T : never, propertyKey: K) => void;
export interface DefineExpressionDecoratorOptions {
    validate?: (value: string) => boolean;
}
export declare function defineExpression(name: string, { validate }?: DefineExpressionDecoratorOptions): <T extends MaterialLike | EffectLike, K extends keyof T>(target: T[K] extends string ? T : never, propertyKey: K) => void;
export {};
