import { Geodetic } from './Geodetic';
export type RectangleTuple = [number, number, number, number];
export interface RectangleLike {
    readonly west: number;
    readonly south: number;
    readonly east: number;
    readonly north: number;
}
export declare class Rectangle {
    west: number;
    south: number;
    east: number;
    north: number;
    static readonly MAX: Rectangle;
    constructor(west?: number, south?: number, east?: number, north?: number);
    get width(): number;
    get height(): number;
    set(west: number, south: number, east: number, north: number): this;
    clone(): Rectangle;
    copy(other: RectangleLike): this;
    equals(other: RectangleLike): boolean;
    at(x: number, y: number, result?: Geodetic): Geodetic;
    fromArray(array: readonly number[], offset?: number): this;
    toArray(array?: number[], offset?: number): number[];
    [Symbol.iterator](): Generator<number>;
}
