import { Data3DTexture, Loader, LoadingManager } from 'three';
export interface EXR3DTextureLoaderOptions {
    width?: number;
    height?: number;
    depth?: number;
}
export declare class EXR3DTextureLoader extends Loader<Data3DTexture> {
    options: EXR3DTextureLoaderOptions;
    constructor(options?: EXR3DTextureLoaderOptions, manager?: LoadingManager);
    load(url: string, onLoad?: (data: Data3DTexture) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): Data3DTexture;
}
