import { Uniform } from 'three';
export type PropertyShorthand<Args extends readonly unknown[]> = Args extends readonly [infer T, infer K, ...infer Rest] ? K extends readonly string[] ? K[number] extends keyof T ? Rest extends readonly unknown[] ? {
    [P in K[number]]: T[P];
} & PropertyShorthand<Rest> : {
    [P in K[number]]: T[P];
} : never : never : {};
export declare function definePropertyShorthand<T, Args extends readonly unknown[]>(destination: T, ...sourceKeysArgs: [...Args]): T & PropertyShorthand<Args>;
export type UniformShorthand<T extends {
    uniforms: Record<K, Uniform>;
}, K extends keyof T['uniforms']> = {
    [P in K]: T['uniforms'][P] extends Uniform<infer U> ? U : never;
};
export declare function defineUniformShorthand<T, S extends {
    uniforms: Record<K, Uniform>;
}, K extends keyof S['uniforms']>(destination: T, source: S, keys: readonly K[]): T & UniformShorthand<S, K>;
