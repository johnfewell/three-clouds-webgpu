interface Includes {
    [key: string]: string | Includes;
}
export declare function resolveIncludes(source: string, includes: Includes): string;
export {};
