import { ElementProps, ThreeElement } from '@react-three/fiber';
import { FC } from 'react';
import { Mesh } from 'three';
import { EllipsoidGeometry } from '../EllipsoidGeometry';
declare module '@react-three/fiber' {
    interface ThreeElements {
        ellipsoidGeometry: ThreeElement<typeof EllipsoidGeometry>;
    }
}
export interface EllipsoidMeshProps extends Omit<ElementProps<typeof Mesh>, 'args'> {
    args?: ConstructorParameters<typeof EllipsoidGeometry>;
}
export declare const EllipsoidMesh: FC<EllipsoidMeshProps>;
