import { ElementProps } from '@react-three/fiber';
import { FC, ReactNode } from 'react';
import { Group } from 'three';
import { SetOptional } from 'type-fest';
import { Ellipsoid } from '../Ellipsoid';
import { GeodeticLike } from '../Geodetic';
declare class EastNorthUpFrameGroup extends Group {
    set(longitude: number, latitude: number, height: number, ellipsoid?: Ellipsoid): void;
}
export interface EastNorthUpFrameProps extends ElementProps<typeof EastNorthUpFrameGroup, EastNorthUpFrameGroup>, SetOptional<GeodeticLike, 'height'> {
    ellipsoid?: Ellipsoid;
    children?: ReactNode;
}
export declare const EastNorthUpFrame: FC<EastNorthUpFrameProps>;
export {};
