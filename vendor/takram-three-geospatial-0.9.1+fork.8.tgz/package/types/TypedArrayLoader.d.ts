import { Loader, LoadingManager } from 'three';
import { TypedArray } from './typedArray';
import { TypedArrayParser } from './typedArrayParsers';
export declare class TypedArrayLoader<T extends TypedArray> extends Loader<T> {
    parser: TypedArrayParser<T>;
    constructor(parser: TypedArrayParser<T>, manager?: LoadingManager);
    load(url: string, onLoad: (data: T) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): void;
}
