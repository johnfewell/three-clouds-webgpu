import { DataTexture, Loader, LoadingManager } from 'three';
export interface EXRTextureLoaderOptions {
    width?: number;
    height?: number;
}
export declare class EXRTextureLoader extends Loader<DataTexture> {
    options: EXRTextureLoaderOptions;
    constructor(options?: EXRTextureLoaderOptions, manager?: LoadingManager);
    load(url: string, onLoad?: (data: DataTexture) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): DataTexture;
}
