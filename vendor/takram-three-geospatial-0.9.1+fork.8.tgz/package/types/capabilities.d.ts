import { WebGLRenderer } from 'three';
import { Renderer } from 'three/webgpu';
export declare function isFloatLinearSupported(renderer: Renderer | WebGLRenderer): boolean;
