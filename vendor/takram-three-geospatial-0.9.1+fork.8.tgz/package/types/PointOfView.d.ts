import { Quaternion, Vector3, Camera } from 'three';
import { Ellipsoid } from './Ellipsoid';
export declare class PointOfView {
    private _distance;
    heading: number;
    private _pitch;
    roll: number;
    constructor(distance?: number, heading?: number, pitch?: number, roll?: number);
    get distance(): number;
    set distance(value: number);
    get pitch(): number;
    set pitch(value: number);
    set(distance: number, heading: number, pitch: number, roll?: number): this;
    clone(): PointOfView;
    copy(other: PointOfView): this;
    equals(other: PointOfView): boolean;
    decompose(target: Vector3, eye: Vector3, quaternion: Quaternion, up?: Vector3, ellipsoid?: Ellipsoid): void;
    setFromCamera(camera: Camera, ellipsoid?: Ellipsoid, target?: Vector3): this | undefined;
}
