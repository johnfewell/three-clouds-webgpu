import { Texture } from 'three';
import { Texture3DNode, Node, NodeBuilder } from 'three/webgpu';
export declare class OutputTexture3DNode extends Texture3DNode {
    static get type(): string;
    owner: Node;
    constructor(owner: Node, texture: Texture);
    setup(builder: NodeBuilder): unknown;
    clone(): this;
}
export declare const outputTexture3D: (...args: ConstructorParameters<typeof OutputTexture3DNode>) => OutputTexture3DNode;
