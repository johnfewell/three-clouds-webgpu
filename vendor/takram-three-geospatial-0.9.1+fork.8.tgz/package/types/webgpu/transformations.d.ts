import { Camera } from 'three';
import { Node } from './node';
export declare const depthToViewZ: import('three/src/nodes/TSL.js').ShaderNodeFn<[depth: number | import('three/webgpu').Node, camera?: Camera | null | undefined, near?: number | import('three/webgpu').Node | null | undefined, far?: number | import('three/webgpu').Node | null | undefined]>;
export declare const logarithmicToPerspectiveDepth: (depth: Node<"float">, near?: Node<"float"> | null, far?: Node<"float"> | null) => Node<"float">;
export declare const perspectiveToLogarithmicDepth: (depth: Node<"float">, near?: Node<"float"> | null, far?: Node<"float"> | null) => Node<"float">;
export declare const screenToPositionView: (uv: Node<"vec2">, depth: Node<"float">, viewZ: Node<"float">, projectionMatrix: Node<"mat4">, inverseProjectionMatrix: Node<"mat4">) => Node<"vec3">;
export declare const turbo: import('three/src/nodes/TSL.js').ShaderNodeFn<[number | import('three/webgpu').Node]>;
export declare const depthToColor: import('three/src/nodes/TSL.js').ShaderNodeFn<[depth: number | import('three/webgpu').Node, camera?: Camera | undefined, near?: number | import('three/webgpu').Node | undefined, far?: number | import('three/webgpu').Node | undefined]>;
export declare const equirectToDirectionWorld: import('three/src/nodes/TSL.js').ShaderNodeFn<[number | import('three/webgpu').Node]>;
