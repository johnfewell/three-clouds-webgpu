import { NodeMaterial, Node, Renderer } from 'three/webgpu';
export declare function debugMaterial(renderer: Renderer, material: NodeMaterial): Promise<string | null>;
export declare function debugVertexNode(renderer: Renderer, material: NodeMaterial): Promise<string | null>;
export declare function debugFragmentNode(renderer: Renderer, material: NodeMaterial): Promise<string | null>;
export declare function debugNode(renderer: Renderer, node: Node): Promise<string | null>;
export declare function hookFunction<T, K extends keyof {
    [K in keyof T as T[K] extends (...args: any[]) => any ? K : never]: unknown;
}, Args extends unknown[] = T[K] extends (...args: any[]) => any ? Parameters<T[K]> : never, Result = T[K] extends (...args: any[]) => any ? ReturnType<T[K]> : never>(target: T, name: K, callback: (...args: Args) => void): T;
