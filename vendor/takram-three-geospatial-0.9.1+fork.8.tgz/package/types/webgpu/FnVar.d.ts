import { ProxiedTuple, ShaderNodeFn } from 'three/src/nodes/TSL.js';
import { NodeBuilder } from 'three/webgpu';
type NonCallable<T> = T extends (...args: any[]) => any ? never : T;
export declare function FnVar<Args extends readonly unknown[], R>(callback: (...args: Args) => (builder: NodeBuilder) => R): ShaderNodeFn<ProxiedTuple<Args>>;
export declare function FnVar<Args extends readonly unknown[], R>(callback: (...args: Args) => NonCallable<R>): ShaderNodeFn<ProxiedTuple<Args>>;
export {};
