import { NodeBuilder, Renderer } from 'three/webgpu';
export declare function isWebGPU(target: NodeBuilder | Renderer | Renderer['backend']): boolean;
