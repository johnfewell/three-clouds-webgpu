export declare const forkBuild: {
    readonly release: 8;
    readonly raySpheresIntersectionsLanes: 4;
    readonly r186Kernels: true;
};
