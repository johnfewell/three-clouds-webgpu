import { Texture3DNode, NodeBuilder } from 'three/webgpu';
export declare class STBNTextureNode extends Texture3DNode {
    url: string;
    constructor();
    customCacheKey(): number;
    setup(builder: NodeBuilder): unknown;
    clone(): this;
}
export declare const stbnTexture: STBNTextureNode;
export declare const stbn: import('three/src/nodes/TSL.js').ShaderCallNodeInternal;
