import { StorageTextureNode, Node, NodeBuilder } from 'three/webgpu';
export declare class StorageTexture3DNode extends StorageTextureNode {
    static get type(): string;
    getDefaultUV(): Node;
    setUpdateMatrix(_value: boolean): void;
    generateUV(builder: NodeBuilder, uvNode: Node): string;
    generateOffset(builder: NodeBuilder, offsetNode: Node): string;
}
export declare const storageTexture3D: (...args: ConstructorParameters<typeof StorageTexture3DNode>) => StorageTexture3DNode;
