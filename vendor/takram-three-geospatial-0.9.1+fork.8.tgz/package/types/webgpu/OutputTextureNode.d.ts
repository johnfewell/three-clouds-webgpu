import { Texture } from 'three';
import { TextureNode, Node, NodeBuilder } from 'three/webgpu';
export declare class OutputTextureNode extends TextureNode {
    static get type(): string;
    owner: Node;
    constructor(owner: Node, texture: Texture);
    setup(builder: NodeBuilder): unknown;
    clone(): this;
}
export declare const outputTexture: (...args: ConstructorParameters<typeof OutputTextureNode>) => OutputTextureNode;
