import { RenderTarget, Texture } from 'three';
import { TempNode, NodeBuilder, TextureNode } from 'three/webgpu';
export declare abstract class FilterNode extends TempNode {
    static get type(): string;
    inputNode?: TextureNode | null;
    resolutionScale: number;
    private textureNode?;
    private readonly renderTargets;
    constructor(inputNode?: TextureNode | null);
    protected createRenderTarget(name?: string): RenderTarget;
    getTextureNode(): TextureNode;
    protected get outputTexture(): Texture | null;
    protected set outputTexture(value: Texture | null);
    abstract setSize(width: number, height: number): this;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
