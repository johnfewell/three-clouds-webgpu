import { Node } from './node';
export declare const interleavedGradientNoise: (seed: Node<"vec2">) => Node<"float">;
export declare const dithering: Node<'vec3'>;
export declare const equirectGrid: (direction: Node<"vec3">, lineWidth: Node<"float">, count?: Node<"vec2">) => Node<"float">;
