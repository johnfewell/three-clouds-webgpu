import { NodeBuilder, NodeFrame, TextureNode } from 'three/webgpu';
import { FilterNode } from './FilterNode';
import { Node } from './node';
export declare abstract class DualMipmapFilterNode extends FilterNode {
    private readonly downsampleRTs;
    private readonly upsampleRTs;
    private readonly downsampleMaterial;
    private readonly upsampleMaterial;
    private readonly mesh;
    private rendererState?;
    protected readonly inputTexelSize: import('three/webgpu').UniformNode<'vec2', import('three').Vector2>;
    protected readonly downsampleNode: TextureNode;
    constructor(inputNode: TextureNode | null | undefined, levels: number);
    setSize(width: number, height: number): this;
    updateBefore({ renderer }: NodeFrame): void;
    protected abstract setupDownsampleNode(builder: NodeBuilder): Node;
    protected abstract setupUpsampleNode(builder: NodeBuilder): Node;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
