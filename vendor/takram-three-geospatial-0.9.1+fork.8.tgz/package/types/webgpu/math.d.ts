export declare const bvecNot: (...params: import('three/webgpu').Node[]) => import('three/webgpu').FunctionOverloadingNode;
export declare const bvecAnd: (...params: import('three/webgpu').Node[]) => import('three/webgpu').FunctionOverloadingNode;
export declare const bvecOr: (...params: import('three/webgpu').Node[]) => import('three/webgpu').FunctionOverloadingNode;
export declare const raySphereIntersection: import('three/src/nodes/TSL.js').ShaderNodeFn<[rayOrigin: number | import('three/webgpu').Node, rayDirection: number | import('three/webgpu').Node, center: number | import('three/webgpu').Node, radius: number | import('three/webgpu').Node]>;
export declare const raySpheresIntersectionsStruct: import('three/src/nodes/TSL.js').Struct;
export declare const raySpheresIntersections: import('three/src/nodes/TSL.js').ShaderNodeFn<[rayOrigin: number | import('three/webgpu').Node, rayDirection: number | import('three/webgpu').Node, center: number | import('three/webgpu').Node, radii: number | import('three/webgpu').Node]>;
export declare const rayEllipsoidIntersection: import('three/src/nodes/TSL.js').ShaderNodeFn<[rayOrigin: number | import('three/webgpu').Node, rayDirection: number | import('three/webgpu').Node, radii: number | import('three/webgpu').Node]>;
