import { Node, NodeFrame } from 'three/webgpu';
export declare const OnFrameUpdate: (callback: (frame: NodeFrame) => void) => Node;
export declare const OnBeforeFrameUpdate: (callback: (frame: NodeFrame) => void) => Node;
