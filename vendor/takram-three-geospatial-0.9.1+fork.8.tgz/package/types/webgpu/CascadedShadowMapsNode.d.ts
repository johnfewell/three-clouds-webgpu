import { DirectionalLight, PerspectiveCamera, Vector2 } from 'three';
import { CSMShadowNode } from 'three/examples/jsm/csm/CSMShadowNode.js';
import { NodeFrame } from 'three/webgpu';
declare module 'three/examples/jsm/csm/CSMShadowNode.js' {
    interface CSMShadowNode {
        _cascades: Vector2[];
    }
}
export declare class CascadedShadowMapsNode extends CSMShadowNode {
    camera: PerspectiveCamera;
    light: DirectionalLight;
    updateBefore(frame: NodeFrame): void;
}
