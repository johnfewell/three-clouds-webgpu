import { NodeBuilder, TextureNode, UniformNode, Vector2 } from 'three/webgpu';
import { DualMipmapFilterNode } from './DualMipmapFilterNode';
import { Node } from './node';
export declare const mipmapBlurDownsample: (inputNode: TextureNode, texelSize: Node<"vec2"> | UniformNode<'vec2', Vector2>) => Node<"vec4">;
export declare const mipmapBlurUpsample: (inputNode: TextureNode, texelSize: Node<"vec2"> | UniformNode<'vec2', Vector2>) => Node<"vec4">;
export declare class MipmapBlurNode extends DualMipmapFilterNode {
    static get type(): string;
    constructor(inputNode?: TextureNode | null, levels?: number);
    protected setupDownsampleNode(builder: NodeBuilder): Node;
    protected setupUpsampleNode(builder: NodeBuilder): Node;
}
export declare const mipmapBlur: (...args: ConstructorParameters<typeof MipmapBlurNode>) => MipmapBlurNode;
