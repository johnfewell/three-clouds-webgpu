import { TextureNode } from 'three/webgpu';
import { Node } from './node';
import { SingleFilterNode } from './SingleFilterNode';
export declare class DownsampleThresholdNode extends SingleFilterNode {
    static get type(): string;
    thresholdLevel: import('three/webgpu').UniformNode<'float', number>;
    thresholdRange: import('three/webgpu').UniformNode<'float', number>;
    constructor(inputNode?: TextureNode | null);
    protected setupOutputNode(): Node;
}
export declare const downsampleThreshold: (...args: ConstructorParameters<typeof DownsampleThresholdNode>) => DownsampleThresholdNode;
