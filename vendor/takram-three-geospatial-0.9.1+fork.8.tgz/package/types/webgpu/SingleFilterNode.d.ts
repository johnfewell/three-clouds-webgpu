import { NodeBuilder, NodeFrame, TextureNode } from 'three/webgpu';
import { FilterNode } from './FilterNode';
import { Node } from './node';
export declare abstract class SingleFilterNode extends FilterNode {
    private readonly renderTarget;
    private readonly material;
    private readonly mesh;
    private rendererState?;
    protected readonly inputTexelSize: import('three/webgpu').UniformNode<'vec2', import('three').Vector2>;
    constructor(inputNode?: TextureNode | null);
    setSize(width: number, height: number): this;
    updateBefore({ renderer }: NodeFrame): void;
    protected abstract setupOutputNode(builder: NodeBuilder): Node;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
