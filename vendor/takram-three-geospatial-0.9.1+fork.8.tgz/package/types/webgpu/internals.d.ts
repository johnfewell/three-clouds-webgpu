import { Vector2 } from 'three';
export declare const bayerOffsets: readonly Vector2[];
export declare const haltonOffsets: readonly Vector2[];
