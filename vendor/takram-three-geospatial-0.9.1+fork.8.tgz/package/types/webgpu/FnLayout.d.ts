import { ProxiedTuple, ShaderCallNodeInternal, ShaderNodeFn } from 'three/src/nodes/TSL.js';
import { NodeBuilder } from 'three/webgpu';
import { Node, NodeType } from './node';
type FnLayoutType = NodeType | (new (...args: any[]) => any) | ((...args: any[]) => any);
export interface FnLayoutInput<T extends FnLayoutType = FnLayoutType> {
    name: string;
    type: T;
}
export interface FnLayout<T extends FnLayoutType, Inputs extends readonly FnLayoutInput[] = []> {
    typeOnly?: boolean;
    name: string;
    type: T;
    inputs?: Inputs;
}
type InferNodeObject<T extends FnLayoutType> = T extends NodeType ? Node<T> : T extends new (...args: any[]) => any ? InstanceType<T> : T extends (...args: any[]) => any ? ReturnType<T> : never;
type InferNodeObjects<Inputs extends readonly FnLayoutInput[]> = {
    [K in keyof Inputs]: Inputs[K] extends FnLayoutInput<infer T> ? InferNodeObject<T> : never;
};
export type FnLayoutResult<T extends FnLayoutType, Inputs extends readonly FnLayoutInput[], Nodes extends readonly unknown[] = InferNodeObjects<Inputs>> = (callback: (...args: [] extends Nodes ? [NodeBuilder] : [Nodes, NodeBuilder]) => InferNodeObject<T> | ShaderCallNodeInternal) => ShaderNodeFn<ProxiedTuple<Nodes>>;
export declare function FnLayout<T extends FnLayoutType, const Inputs extends readonly FnLayoutInput[] = []>({ typeOnly, ...layout }: FnLayout<T, Inputs>): FnLayoutResult<T, Inputs>;
export {};
