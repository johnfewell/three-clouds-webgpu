import { Vector3 } from 'three';
export interface ProjectOnEllipsoidSurfaceOptions {
    centerTolerance?: number;
}
export declare function projectOnEllipsoidSurface(position: Vector3, reciprocalRadiiSquared: Vector3, result?: Vector3, options?: ProjectOnEllipsoidSurfaceOptions): Vector3 | undefined;
