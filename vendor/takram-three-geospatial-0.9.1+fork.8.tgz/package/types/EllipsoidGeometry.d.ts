import { BufferGeometry, Vector3 } from 'three';
export interface EllipsoidGeometryParameters {
    radii: Vector3;
    longitudeSegments?: number;
    latitudeSegments?: number;
}
export declare class EllipsoidGeometry extends BufferGeometry {
    readonly type = "EllipsoidGeometry";
    parameters: EllipsoidGeometryParameters;
    constructor(radii?: Vector3, longitudeSegments?: number, latitudeSegments?: number);
    copy(source: EllipsoidGeometry): this;
}
