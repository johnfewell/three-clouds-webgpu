import { BufferGeometry, TypedArray, Vector3Like } from 'three';
export interface BufferGeometryLike {
    attributes: Record<string, {
        array: TypedArray;
        itemSize: number;
        normalized?: boolean;
    }>;
    index?: {
        array: TypedArray;
        itemSize: number;
        normalized?: boolean;
    } | null;
    boundingBox?: {
        min: Vector3Like;
        max: Vector3Like;
    } | null;
    boundingSphere?: {
        center: Vector3Like;
        radius: number;
    } | null;
}
export declare function toBufferGeometryLike(geometry: BufferGeometry): [BufferGeometryLike, ArrayBufferLike[]];
export declare function fromBufferGeometryLike(input: BufferGeometryLike, result?: BufferGeometry<import('three').NormalBufferAttributes, import('three').BufferGeometryEventMap>): BufferGeometry;
