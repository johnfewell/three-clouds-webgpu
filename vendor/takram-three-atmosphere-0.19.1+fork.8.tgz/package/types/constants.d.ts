import { Matrix3 } from 'three';
export declare const DEFAULT_PRECOMPUTED_TEXTURES_URL = "https://media.githubusercontent.com/media/takram-design-engineering/three-geospatial/eac103980f20c0956f2d3215833e73514be08462/packages/atmosphere/assets";
export declare const DEFAULT_STARS_DATA_URL = "https://media.githubusercontent.com/media/takram-design-engineering/three-geospatial/eac103980f20c0956f2d3215833e73514be08462/packages/atmosphere/assets/stars.bin";
export declare const IRRADIANCE_TEXTURE_WIDTH = 64;
export declare const IRRADIANCE_TEXTURE_HEIGHT = 16;
export declare const SCATTERING_TEXTURE_R_SIZE = 32;
export declare const SCATTERING_TEXTURE_MU_SIZE = 128;
export declare const SCATTERING_TEXTURE_MU_S_SIZE = 32;
export declare const SCATTERING_TEXTURE_NU_SIZE = 8;
export declare const SCATTERING_TEXTURE_WIDTH: number;
export declare const SCATTERING_TEXTURE_HEIGHT = 128;
export declare const SCATTERING_TEXTURE_DEPTH = 32;
export declare const TRANSMITTANCE_TEXTURE_WIDTH = 256;
export declare const TRANSMITTANCE_TEXTURE_HEIGHT = 64;
export declare const METER_TO_LENGTH_UNIT: number;
/** @deprecated The render order of the sky shouldn't matter. */
export declare const SKY_RENDER_ORDER = 100;
export declare const XYZ_TO_SRGB: Matrix3;
