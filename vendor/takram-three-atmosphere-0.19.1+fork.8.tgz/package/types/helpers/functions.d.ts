import { AtmosphereParameters } from '../AtmosphereParameters';
export declare function safeSqrt(a: number): number;
export declare function clampDistance(d: number): number;
export declare function rayIntersectsGround(atmosphere: AtmosphereParameters, r: number, mu: number): boolean;
export declare function distanceToTopAtmosphereBoundary(atmosphere: AtmosphereParameters, r: number, mu: number): number;
export declare function getTextureCoordFromUnitRange(x: number, textureSize: number): number;
