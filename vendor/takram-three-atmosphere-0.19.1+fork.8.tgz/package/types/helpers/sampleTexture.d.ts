import { Vector3, Texture, Vector2 } from 'three';
export declare function sampleTexture(texture: Texture, uv: Vector2, result: Vector3): Vector3;
