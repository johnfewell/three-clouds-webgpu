import { Vector3 } from 'three';
export declare const MIN_LAMBDA = 360;
export declare const MAX_LAMBDA = 830;
export declare function getCIEColorMatchingFunctionValue(wavelength: number, result: Vector3): Vector3;
