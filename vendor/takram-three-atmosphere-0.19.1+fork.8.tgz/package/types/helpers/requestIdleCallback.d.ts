export declare const requestIdleCallback: typeof window.requestIdleCallback;
export declare const cancelIdleCallback: typeof window.cancelIdleCallback;
