import { Vector3 } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
export declare function getAltitudeCorrectionOffset(cameraPosition: Vector3, bottomRadius: number, ellipsoid: Ellipsoid, result: Vector3): Vector3;
