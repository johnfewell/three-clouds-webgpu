import { Color, Uniform, Vector3 } from 'three';
declare const paramKeys: readonly ["solarIrradiance", "sunAngularRadius", "bottomRadius", "topRadius", "rayleighDensity", "rayleighScattering", "mieDensity", "mieScattering", "mieExtinction", "miePhaseFunctionG", "absorptionDensity", "absorptionExtinction", "groundAlbedo", "muSMin", "skyRadianceToLuminance", "sunRadianceToLuminance"];
export interface AtmosphereParametersOptions extends Partial<Pick<AtmosphereParameters, (typeof paramKeys)[number]>> {
}
export declare class DensityProfileLayer {
    width: number;
    expTerm: number;
    expScale: number;
    linearTerm: number;
    constantTerm: number;
    constructor(width: number, expTerm: number, expScale: number, linearTerm: number, constantTerm: number);
    toUniform(): Uniform<{
        width: number;
        exp_term: number;
        exp_scale: number;
        linear_term: number;
        constant_term: number;
    }>;
}
type DensityProfile = [DensityProfileLayer, DensityProfileLayer];
export declare class AtmosphereParameters {
    static readonly DEFAULT: AtmosphereParameters;
    solarIrradiance: Vector3;
    sunAngularRadius: number;
    bottomRadius: number;
    topRadius: number;
    rayleighDensity: DensityProfile;
    rayleighScattering: Vector3;
    mieDensity: DensityProfile;
    mieScattering: Vector3;
    mieExtinction: Vector3;
    miePhaseFunctionG: number;
    absorptionDensity: DensityProfile;
    absorptionExtinction: Vector3;
    groundAlbedo: Color;
    muSMin: number;
    sunRadianceToLuminance: Vector3;
    skyRadianceToLuminance: Vector3;
    sunRadianceToRelativeLuminance: Vector3;
    skyRadianceToRelativeLuminance: Vector3;
    constructor(options?: AtmosphereParametersOptions);
    toUniform(): Uniform<{
        solar_irradiance: Vector3;
        sun_angular_radius: number;
        bottom_radius: number;
        top_radius: number;
        rayleigh_density: {
            layers: {
                width: number;
                exp_term: number;
                exp_scale: number;
                linear_term: number;
                constant_term: number;
            }[];
        };
        rayleigh_scattering: Vector3;
        mie_density: {
            layers: {
                width: number;
                exp_term: number;
                exp_scale: number;
                linear_term: number;
                constant_term: number;
            }[];
        };
        mie_scattering: Vector3;
        mie_extinction: Vector3;
        mie_phase_function_g: number;
        absorption_density: {
            layers: {
                width: number;
                exp_term: number;
                exp_scale: number;
                linear_term: number;
                constant_term: number;
            }[];
        };
        absorption_extinction: Vector3;
        ground_albedo: Color;
        mu_s_min: number;
    }>;
}
export type AtmosphereParametersUniform = ReturnType<AtmosphereParameters['toUniform']>;
export {};
