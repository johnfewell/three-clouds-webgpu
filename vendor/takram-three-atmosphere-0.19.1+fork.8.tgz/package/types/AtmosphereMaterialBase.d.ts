import { Matrix4, RawShaderMaterial, Uniform, Vector3, BufferGeometry, Camera, Data3DTexture, Group, Object3D, Scene, ShaderMaterialParameters, Texture, WebGLProgramParametersWithUniforms, WebGLRenderer } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereParameters, AtmosphereParametersUniform } from './AtmosphereParameters';
export interface AtmosphereMaterialProps {
    irradianceTexture?: Texture | null;
    scatteringTexture?: Data3DTexture | null;
    transmittanceTexture?: Texture | null;
    singleMieScatteringTexture?: Data3DTexture | null;
    higherOrderScatteringTexture?: Data3DTexture | null;
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
    sunDirection?: Vector3;
    sunAngularRadius?: number;
    ground?: boolean;
    renderTargetCount?: number;
}
export interface AtmosphereMaterialBaseParameters extends Partial<ShaderMaterialParameters>, AtmosphereMaterialProps {
}
export declare const atmosphereMaterialParametersBaseDefaults: {
    ellipsoid: Ellipsoid;
    correctAltitude: true;
    renderTargetCount: number;
};
export interface AtmosphereMaterialBaseUniforms {
    [key: string]: Uniform<unknown>;
    cameraPosition: Uniform<Vector3>;
    worldToECEFMatrix: Uniform<Matrix4>;
    altitudeCorrection: Uniform<Vector3>;
    sunDirection: Uniform<Vector3>;
    cosSunAngularRadius: Uniform<number>;
    ATMOSPHERE: AtmosphereParametersUniform;
    SUN_SPECTRAL_RADIANCE_TO_LUMINANCE: Uniform<Vector3>;
    SKY_SPECTRAL_RADIANCE_TO_LUMINANCE: Uniform<Vector3>;
    irradiance_texture: Uniform<Texture | null>;
    scattering_texture: Uniform<Data3DTexture | null>;
    transmittance_texture: Uniform<Texture | null>;
    single_mie_scattering_texture: Uniform<Data3DTexture | null>;
    higher_order_scattering_texture: Uniform<Data3DTexture | null>;
}
export declare abstract class AtmosphereMaterialBase extends RawShaderMaterial {
    protected readonly atmosphere: AtmosphereParameters;
    uniforms: AtmosphereMaterialBaseUniforms;
    ellipsoid: Ellipsoid;
    correctAltitude: boolean;
    private _renderTargetCount;
    constructor(params?: AtmosphereMaterialBaseParameters, atmosphere?: AtmosphereParameters);
    copyCameraSettings(camera: Camera): void;
    onBeforeCompile(parameters: WebGLProgramParametersWithUniforms, renderer: WebGLRenderer): void;
    onBeforeRender(renderer: WebGLRenderer, scene: Scene, camera: Camera, geometry: BufferGeometry, object: Object3D, group: Group): void;
    get irradianceTexture(): Texture | null;
    set irradianceTexture(value: Texture | null);
    get scatteringTexture(): Data3DTexture | null;
    set scatteringTexture(value: Data3DTexture | null);
    get transmittanceTexture(): Texture | null;
    set transmittanceTexture(value: Texture | null);
    /** @private */
    combinedScatteringTextures: boolean;
    get singleMieScatteringTexture(): Data3DTexture | null;
    set singleMieScatteringTexture(value: Data3DTexture | null);
    /** @private */
    hasHigherOrderScatteringTexture: boolean;
    get higherOrderScatteringTexture(): Data3DTexture | null;
    set higherOrderScatteringTexture(value: Data3DTexture | null);
    get worldToECEFMatrix(): Matrix4;
    get sunDirection(): Vector3;
    get sunAngularRadius(): number;
    set sunAngularRadius(value: number);
    /** @package */
    get renderTargetCount(): number;
    /** @package */
    set renderTargetCount(value: number);
}
