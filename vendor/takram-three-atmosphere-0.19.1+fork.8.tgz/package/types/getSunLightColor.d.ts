import { Color, Vector3, Texture } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereParameters } from './AtmosphereParameters';
export interface SunLightColorOptions {
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
}
export declare function getSunLightColor(transmittanceTexture: Texture, worldPosition: Vector3, sunDirection: Vector3, result?: Color, { ellipsoid, correctAltitude }?: SunLightColorOptions, atmosphere?: AtmosphereParameters): Color;
