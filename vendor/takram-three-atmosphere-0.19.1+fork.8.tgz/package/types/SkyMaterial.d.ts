import { Color, Matrix4, Uniform, Vector3, BufferGeometry, Camera, Group, Object3D, Scene, Texture, WebGLRenderer } from 'three';
import { AtmosphereMaterialBase, AtmosphereMaterialBaseParameters, AtmosphereMaterialBaseUniforms } from './AtmosphereMaterialBase';
import { AtmosphereShadowLength } from './types';
export interface SkyMaterialParameters extends AtmosphereMaterialBaseParameters {
    sun?: boolean;
    moon?: boolean;
    moonDirection?: Vector3;
    moonAngularRadius?: number;
    lunarRadianceScale?: number;
    ground?: boolean;
    groundAlbedo?: Color;
}
export declare const skyMaterialParametersDefaults: {
    sun: true;
    moon: true;
    moonAngularRadius: number;
    lunarRadianceScale: number;
    ground: true;
    groundAlbedo: Color;
    ellipsoid: import('@takram/three-geospatial').Ellipsoid;
    correctAltitude: true;
    renderTargetCount: number;
};
export interface SkyMaterialUniforms {
    [key: string]: Uniform<unknown>;
    inverseProjectionMatrix: Uniform<Matrix4>;
    inverseViewMatrix: Uniform<Matrix4>;
    moonDirection: Uniform<Vector3>;
    moonAngularRadius: Uniform<number>;
    lunarRadianceScale: Uniform<number>;
    groundAlbedo: Uniform<Color>;
    shadowLengthBuffer: Uniform<Texture | null>;
}
export declare class SkyMaterial extends AtmosphereMaterialBase {
    uniforms: AtmosphereMaterialBaseUniforms & SkyMaterialUniforms;
    shadowLength: AtmosphereShadowLength | null;
    constructor(params?: SkyMaterialParameters);
    onBeforeRender(renderer: WebGLRenderer, scene: Scene, camera: Camera, geometry: BufferGeometry, object: Object3D, group: Group): void;
    sun: boolean;
    moon: boolean;
    ground: boolean;
    get moonDirection(): Vector3;
    get moonAngularRadius(): number;
    set moonAngularRadius(value: number);
    get lunarRadianceScale(): number;
    set lunarRadianceScale(value: number);
    get groundAlbedo(): Color;
}
