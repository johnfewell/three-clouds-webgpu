import { ElementProps } from '@react-three/fiber';
import { FC } from 'react';
import { BufferGeometry, Color, Mesh, Vector3 } from 'three';
import { AtmosphereMaterialProps } from '../AtmosphereMaterialBase';
import { SkyMaterial } from '../SkyMaterial';
export type SkyImpl = Mesh<BufferGeometry, SkyMaterial>;
export interface SkyProps extends ElementProps<typeof Mesh, Mesh & Required<AtmosphereMaterialProps> & {
    sun: boolean;
    moon: boolean;
    moonDirection: Vector3;
    moonAngularRadius: number;
    lunarRadianceScale: number;
    groundAlbedo: Color;
}> {
}
export declare const Sky: FC<SkyProps>;
