import { ElementProps } from '@react-three/fiber';
import { FC } from 'react';
import { Data3DTexture } from 'three';
import { AerialPerspectiveEffect } from '../AerialPerspectiveEffect';
export interface AerialPerspectiveProps extends Omit<ElementProps<typeof AerialPerspectiveEffect, AerialPerspectiveEffect>, 'stbnTexture'> {
    stbnTexture?: Data3DTexture | string;
}
export declare const AerialPerspective: FC<AerialPerspectiveProps>;
