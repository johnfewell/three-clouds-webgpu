import { ElementProps } from '@react-three/fiber';
import { FC } from 'react';
import { Points } from 'three';
import { AtmosphereMaterialProps } from '../AtmosphereMaterialBase';
import { StarsGeometry } from '../StarsGeometry';
import { StarsMaterial } from '../StarsMaterial';
export type StarsImpl = Points<StarsGeometry, StarsMaterial>;
export interface StarsProps extends ElementProps<typeof Points>, AtmosphereMaterialProps {
    data?: ArrayBuffer | string;
    pointSize?: number;
    intensity?: number;
    background?: boolean;
}
export declare const Stars: FC<StarsProps>;
