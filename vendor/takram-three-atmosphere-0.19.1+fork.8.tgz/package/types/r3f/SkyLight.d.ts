import { ThreeElement } from '@react-three/fiber';
import { ComponentPropsWithoutRef, FC, Ref } from 'react';
import { SkyLightProbe } from '../SkyLightProbe';
declare module '@react-three/fiber' {
    interface ThreeElements {
        skyLightProbe: ThreeElement<typeof SkyLightProbe>;
    }
}
export interface SkyLightProps extends ComponentPropsWithoutRef<'skyLightProbe'> {
    ref?: Ref<SkyLightProbe>;
}
export declare const SkyLight: FC<SkyLightProps>;
