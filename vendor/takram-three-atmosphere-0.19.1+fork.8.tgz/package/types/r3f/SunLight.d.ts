import { ThreeElement } from '@react-three/fiber';
import { ComponentPropsWithoutRef, FC, Ref } from 'react';
import { SunDirectionalLight } from '../SunDirectionalLight';
declare module '@react-three/fiber' {
    interface ThreeElements {
        sunDirectionalLight: ThreeElement<typeof SunDirectionalLight>;
    }
}
export interface SunLightProps extends Omit<ComponentPropsWithoutRef<'sunDirectionalLight'>, 'target'> {
    ref?: Ref<SunDirectionalLight>;
}
export declare const SunLight: FC<SunLightProps>;
