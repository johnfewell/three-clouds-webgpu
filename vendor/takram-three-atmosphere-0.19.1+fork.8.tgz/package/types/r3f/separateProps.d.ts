import { OverwriteMathProps } from '@takram/three-geospatial/r3f';
import { AtmosphereMaterialProps } from '../AtmosphereMaterialBase';
export declare function separateProps<T extends OverwriteMathProps<AtmosphereMaterialProps>>(params: T): [
    OverwriteMathProps<AtmosphereMaterialProps>,
    Omit<T, keyof AtmosphereMaterialProps>
];
