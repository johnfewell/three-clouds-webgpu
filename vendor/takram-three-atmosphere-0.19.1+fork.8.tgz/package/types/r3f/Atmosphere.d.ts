import { FC, ReactNode, Ref } from 'react';
import { Matrix4, Vector3 } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereLightingMask, AtmosphereOverlay, AtmosphereShadow, AtmosphereShadowLength, PrecomputedTextures } from '../types';
export interface AtmosphereTransientStates {
    sunDirection: Vector3;
    moonDirection: Vector3;
    worldToECEFMatrix: Matrix4;
    inertialToECEFMatrix: Matrix4;
    overlay: AtmosphereOverlay | null;
    shadow: AtmosphereShadow | null;
    shadowLength: AtmosphereShadowLength | null;
    lightingMask: AtmosphereLightingMask | null;
}
export interface AtmosphereContextValue {
    textures?: PrecomputedTextures | null;
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
    transientStates?: AtmosphereTransientStates;
}
export declare const AtmosphereContext: import('react').Context<AtmosphereContextValue>;
export interface AtmosphereApi extends AtmosphereTransientStates {
    textures?: PrecomputedTextures;
    updateByDate: (date: number | Date) => void;
}
export interface AtmosphereProps {
    ref?: Ref<AtmosphereApi>;
    textures?: PrecomputedTextures | string;
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
    ground?: boolean;
    date?: number | Date;
    children?: ReactNode;
}
export declare const Atmosphere: FC<AtmosphereProps>;
