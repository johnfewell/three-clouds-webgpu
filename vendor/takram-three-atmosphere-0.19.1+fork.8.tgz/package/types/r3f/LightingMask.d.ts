import { ThreeElement } from '@react-three/fiber';
import { ComponentPropsWithoutRef, FC, Ref } from 'react';
import { LightingMaskPass } from '../LightingMaskPass';
declare module '@react-three/fiber' {
    interface ThreeElements {
        lightingMaskPass: ThreeElement<typeof LightingMaskPass>;
    }
}
export interface LightingMaskProps extends Omit<ComponentPropsWithoutRef<'lightingMaskPass'>, 'args'> {
    ref?: Ref<LightingMaskPass>;
}
export declare const LightingMask: FC<LightingMaskProps>;
