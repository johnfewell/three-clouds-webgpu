export declare const runtime: string;
export declare const common: string;
export declare const definitions: string;
export declare const precompute: string;
