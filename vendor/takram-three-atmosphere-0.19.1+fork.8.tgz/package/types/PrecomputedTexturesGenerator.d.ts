import { Matrix3, RawShaderMaterial, Vector3, WebGL3DRenderTarget, WebGLRenderTarget, ShaderMaterialParameters, WebGLRenderer } from 'three';
import { AnyFloatType } from '@takram/three-geospatial';
import { AtmosphereParameters } from './AtmosphereParameters';
import { PrecomputedTextures } from './types';
declare class Context {
    lambdas: Vector3;
    luminanceFromRadiance: Matrix3;
    opticalDepth?: WebGLRenderTarget;
    deltaIrradiance: WebGLRenderTarget;
    deltaRayleighScattering: WebGL3DRenderTarget;
    deltaMieScattering: WebGL3DRenderTarget;
    deltaScatteringDensity: WebGL3DRenderTarget;
    deltaMultipleScattering: WebGL3DRenderTarget;
    constructor(type: AnyFloatType);
    dispose(): void;
}
declare class PrecomputeMaterial extends RawShaderMaterial {
    constructor(params: ShaderMaterialParameters);
    set additive(value: boolean);
    setUniforms(context: Context): void;
}
export interface PrecomputedTexturesGeneratorOptions {
    type?: AnyFloatType;
    combinedScattering?: boolean;
    higherOrderScattering?: boolean;
}
export declare class PrecomputedTexturesGenerator {
    readonly transmittanceRenderTarget: WebGLRenderTarget;
    readonly scatteringRenderTarget: WebGL3DRenderTarget;
    readonly irradianceRenderTarget: WebGLRenderTarget;
    readonly singleMieScatteringRenderTarget?: WebGL3DRenderTarget;
    readonly higherOrderScatteringRenderTarget?: WebGL3DRenderTarget;
    readonly textures: PrecomputedTextures;
    transmittanceMaterial: PrecomputeMaterial;
    directIrradianceMaterial: PrecomputeMaterial;
    singleScatteringMaterial: PrecomputeMaterial;
    scatteringDensityMaterial: PrecomputeMaterial;
    indirectIrradianceMaterial: PrecomputeMaterial;
    multipleScatteringMaterial: PrecomputeMaterial;
    private readonly renderer;
    private readonly type;
    private readonly mesh;
    private readonly scene;
    private readonly camera;
    private updating;
    private disposeQueue;
    constructor(renderer: WebGLRenderer, { type, combinedScattering, higherOrderScattering }?: PrecomputedTexturesGeneratorOptions);
    private render3DRenderTarget;
    private computeTransmittance;
    private computeOpticalDepth;
    private computeDirectIrradiance;
    private computeSingleScattering;
    private computeScatteringDensity;
    private computeIndirectIrradiance;
    private computeMultipleScattering;
    private precompute;
    update(atmosphere?: AtmosphereParameters): Promise<PrecomputedTextures>;
    dispose(options?: {
        textures?: boolean;
    }): void;
}
export {};
