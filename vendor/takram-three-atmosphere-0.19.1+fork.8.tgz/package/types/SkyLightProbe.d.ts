import { LightProbe, Matrix4, Vector3, Texture } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereParameters } from './AtmosphereParameters';
export interface SkyLightProbeParameters {
    irradianceTexture?: Texture | null;
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
    sunDirection?: Vector3;
}
export declare const skyLightProbeParametersDefaults: {
    ellipsoid: Ellipsoid;
    correctAltitude: true;
};
export declare class SkyLightProbe extends LightProbe {
    private readonly atmosphere;
    irradianceTexture: Texture | null;
    ellipsoid: Ellipsoid;
    readonly worldToECEFMatrix: Matrix4;
    correctAltitude: boolean;
    readonly sunDirection: Vector3;
    constructor(params?: SkyLightProbeParameters, atmosphere?: AtmosphereParameters);
    update(): void;
}
