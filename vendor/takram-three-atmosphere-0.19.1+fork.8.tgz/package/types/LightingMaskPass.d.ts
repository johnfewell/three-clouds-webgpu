import { Pass, Selection } from 'postprocessing';
import { WebGLRenderTarget, Camera, DepthPackingStrategies, Scene, Texture, TextureDataType, WebGLRenderer } from 'three';
export declare class LightingMaskPass extends Pass {
    private readonly renderPass;
    private readonly depthTexture;
    private readonly renderTarget;
    private readonly depthCopyPass0;
    private readonly depthCopyPass1;
    private readonly clearPass;
    private readonly depthMaskMaterial;
    private readonly depthMaskPass;
    readonly selection: Selection;
    constructor(scene: Scene, camera: Camera);
    set mainScene(value: Scene);
    set mainCamera(value: Camera);
    initialize(renderer: WebGLRenderer, alpha: boolean, frameBufferType: TextureDataType): void;
    setDepthTexture(depthTexture: Texture, depthPacking?: DepthPackingStrategies): void;
    render(renderer: WebGLRenderer, inputBuffer: WebGLRenderTarget | null, outputBuffer: WebGLRenderTarget | null, deltaTime?: number, stencilTest?: boolean): void;
    setSize(width: number, height: number): void;
    get texture(): Texture;
    get selectionLayer(): number;
    set selectionLayer(value: number);
    get inverted(): boolean;
    set inverted(value: boolean);
}
