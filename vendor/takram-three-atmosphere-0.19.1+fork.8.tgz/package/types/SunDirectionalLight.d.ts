import { DirectionalLight, Matrix4, Vector3, Texture } from 'three';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereParameters } from './AtmosphereParameters';
export interface SunDirectionalLightParameters {
    transmittanceTexture?: Texture | null;
    ellipsoid?: Ellipsoid;
    correctAltitude?: boolean;
    sunDirection?: Vector3;
    distance?: number;
}
export declare const sunDirectionalLightParametersDefaults: {
    ellipsoid: Ellipsoid;
    correctAltitude: true;
    distance: number;
};
export declare class SunDirectionalLight extends DirectionalLight {
    private readonly atmosphere;
    transmittanceTexture: Texture | null;
    ellipsoid: Ellipsoid;
    readonly worldToECEFMatrix: Matrix4;
    correctAltitude: boolean;
    readonly sunDirection: Vector3;
    distance: number;
    constructor(params?: SunDirectionalLightParameters, atmosphere?: AtmosphereParameters);
    update(): void;
}
