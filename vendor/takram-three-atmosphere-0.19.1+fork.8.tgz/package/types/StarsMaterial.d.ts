import { Matrix4, Uniform, Vector2, BufferGeometry, Group, Object3D, OrthographicCamera, PerspectiveCamera, Scene, WebGLRenderer } from 'three';
import { AtmosphereMaterialBase, AtmosphereMaterialBaseParameters, AtmosphereMaterialBaseUniforms } from './AtmosphereMaterialBase';
export interface StarsMaterialParameters extends AtmosphereMaterialBaseParameters {
    pointSize?: number;
    intensity?: number;
    background?: boolean;
    ground?: boolean;
}
export declare const starsMaterialParametersDefaults: {
    pointSize: number;
    intensity: number;
    background: true;
    ground: true;
    ellipsoid: import('@takram/three-geospatial').Ellipsoid;
    correctAltitude: true;
    renderTargetCount: number;
};
export interface StarsMaterialUniforms {
    [key: string]: Uniform<unknown>;
    projectionMatrix: Uniform<Matrix4>;
    modelViewMatrix: Uniform<Matrix4>;
    viewMatrix: Uniform<Matrix4>;
    matrixWorld: Uniform<Matrix4>;
    cameraFar: Uniform<number>;
    pointSize: Uniform<number>;
    magnitudeRange: Uniform<Vector2>;
    intensity: Uniform<number>;
}
export declare class StarsMaterial extends AtmosphereMaterialBase {
    uniforms: AtmosphereMaterialBaseUniforms & StarsMaterialUniforms;
    pointSize: number;
    constructor(params?: StarsMaterialParameters);
    onBeforeRender(renderer: WebGLRenderer, scene: Scene, camera: PerspectiveCamera | OrthographicCamera, geometry: BufferGeometry, object: Object3D, group: Group): void;
    get magnitudeRange(): Vector2;
    get intensity(): number;
    set intensity(value: number);
    background: boolean;
    ground: boolean;
}
