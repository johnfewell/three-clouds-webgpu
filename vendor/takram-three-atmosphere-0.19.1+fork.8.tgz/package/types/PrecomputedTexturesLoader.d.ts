import { Loader, LoadingManager, WebGLRenderer } from 'three';
import { AnyFloatType } from '@takram/three-geospatial';
import { PrecomputedTextures } from './types';
export type PrecomputedTexturesFormat = 'binary' | 'exr';
export interface PrecomputedTexturesLoaderOptions {
    format?: PrecomputedTexturesFormat;
    type?: AnyFloatType;
    combinedScattering?: boolean;
    higherOrderScattering?: boolean;
}
export declare class PrecomputedTexturesLoader extends Loader<PrecomputedTextures> {
    format: PrecomputedTexturesFormat;
    type: AnyFloatType;
    combinedScattering: boolean;
    higherOrderScattering: boolean;
    constructor({ format, type, combinedScattering, higherOrderScattering }?: PrecomputedTexturesLoaderOptions, manager?: LoadingManager);
    setType(renderer: WebGLRenderer): this;
    load(url: string, onLoad?: (data: PrecomputedTextures) => void, onProgress?: (event: ProgressEvent) => void, onError?: (error: unknown) => void): PrecomputedTextures;
}
