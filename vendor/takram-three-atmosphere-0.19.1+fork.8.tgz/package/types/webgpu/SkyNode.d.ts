import { TempNode, NodeBuilder } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
import { MoonNode } from './MoonNode';
import { StarsNode } from './StarsNode';
import { SunNode } from './SunNode';
declare const CAMERA = "CAMERA";
declare const EQUIRECTANGULAR = "EQUIRECTANGULAR";
type SkyNodeScope = typeof CAMERA | typeof EQUIRECTANGULAR;
export declare class SkyNode extends TempNode {
    static get type(): string;
    private readonly scope;
    shadowLengthNode?: Node<'vec2'> | null;
    sunNode: SunNode;
    moonNode: MoonNode;
    starsNode: StarsNode;
    showSun: boolean;
    showMoon: boolean;
    showStars: boolean;
    moonScattering: boolean;
    useContextCamera: boolean;
    constructor(scope: SkyNodeScope, shadowLengthNode?: Node<'vec2'> | null);
    customCacheKey(): number;
    setup(builder: NodeBuilder): unknown;
}
export declare const sky: (shadowLengthNode?: number | import('three/webgpu').Node | null | undefined) => SkyNode;
export declare const skyBackground: (shadowLengthNode?: number | import('three/webgpu').Node | null | undefined) => SkyNode;
export {};
