import { TempNode, NodeBuilder } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class SunNode extends TempNode {
    static get type(): string;
    rayDirectionECEF?: Node;
    angularRadius: import('three/webgpu').UniformNode<'float', number>;
    intensity: import('three/webgpu').UniformNode<'float', number>;
    constructor();
    setup(builder: NodeBuilder): unknown;
}
