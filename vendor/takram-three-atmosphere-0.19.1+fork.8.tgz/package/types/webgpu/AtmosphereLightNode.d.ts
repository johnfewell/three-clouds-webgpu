import { DirectLightData } from 'three/src/nodes/TSL.js';
import { AnalyticLightNode, NodeBuilder, NodeFrame } from 'three/webgpu';
import { AtmosphereLight } from './AtmosphereLight';
export declare class AtmosphereLightNode extends AnalyticLightNode<AtmosphereLight> {
    static get type(): string;
    private atmosphereContext?;
    private readonly intensity;
    private readonly directionECEF;
    constructor(light?: AtmosphereLight | null);
    updateBefore(frame: NodeFrame): undefined;
    update(frame: NodeFrame): undefined;
    setup(builder: NodeBuilder): ReturnType<AnalyticLightNode['setup']>;
    setupDirect(builder: NodeBuilder): DirectLightData | undefined;
}
