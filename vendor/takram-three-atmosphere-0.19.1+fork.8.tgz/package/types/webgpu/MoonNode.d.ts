import { TempNode, NodeBuilder, TextureNode } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class MoonNode extends TempNode {
    static get type(): string;
    rayDirectionECEF?: Node;
    colorNode?: TextureNode | null;
    displacementNode?: TextureNode | null;
    angularRadius: import('three/webgpu').UniformNode<'float', number>;
    intensity: import('three/webgpu').UniformNode<'float', number>;
    displacementScale: import('three/webgpu').UniformNode<'float', number>;
    constructor();
    setup(builder: NodeBuilder): unknown;
}
