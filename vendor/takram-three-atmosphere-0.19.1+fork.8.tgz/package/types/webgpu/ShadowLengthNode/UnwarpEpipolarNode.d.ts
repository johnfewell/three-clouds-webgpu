import { Camera, Vector2, Vector4 } from 'three';
import { NodeBuilder, NodeFrame, TextureNode, UniformNode } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class UnwarpEpipolarNode extends Node {
    static get type(): string;
    sliceEndpointsNode: TextureNode;
    coordinateNode: TextureNode;
    epipolarShadowLengthNode: TextureNode;
    viewZUnitNode: TextureNode;
    camera: Camera;
    epipolarSliceCount: UniformNode<'float', number>;
    maxSliceSampleCount: UniformNode<'float', number>;
    screenSize: UniformNode<'vec2', Vector2>;
    lightScreenPosition: UniformNode<'vec4', Vector4>;
    refinementThreshold: UniformNode<'float', number>;
    private readonly textureNode;
    private readonly renderTarget;
    private readonly material;
    private readonly mesh;
    private rendererState?;
    constructor();
    getTextureNode(): TextureNode;
    update({ renderer }: NodeFrame): void;
    private setupFragmentNode;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
