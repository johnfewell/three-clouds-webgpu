import { CSMShadowNode } from 'three/examples/jsm/csm/CSMShadowNode.js';
import { NodeBuilder, NodeFrame, TextureNode, UniformNode } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class MinMaxLevelsNode extends Node {
    static get type(): string;
    csmShadowNode: CSMShadowNode;
    sliceUVDirectionNode: TextureNode;
    shadowDepthNodes: TextureNode[];
    epipolarSliceCount: UniformNode<'float', number>;
    maxSliceSampleCount: UniformNode<'float', number>;
    firstCascade: UniformNode<'uint', number>;
    private readonly textureNode;
    private readonly renderTargetA;
    private readonly renderTargetB;
    private readonly gatherMaterial;
    private readonly mipmapMaterial;
    private readonly mesh;
    private rendererState?;
    private readonly mipmapSourceNode;
    private readonly mipmapOffsetNode;
    constructor();
    getTextureNode(): TextureNode;
    private render;
    update({ renderer }: NodeFrame): void;
    private setupGatherNode;
    private setupMipmapNode;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
