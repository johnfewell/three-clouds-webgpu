import { Camera, Vector2 } from 'three';
import { CSMShadowNode } from 'three/examples/jsm/csm/CSMShadowNode.js';
import { NodeBuilder, NodeFrame, TextureNode, UniformArrayNode, UniformNode } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class SliceUVDirectionNode extends Node {
    static get type(): string;
    depthNode: TextureNode;
    csmShadowNode: CSMShadowNode;
    sliceEndpointsNode: TextureNode;
    camera: Camera;
    epipolarSliceCount: UniformNode<'float', number>;
    maxSliceSampleCount: UniformNode<'float', number>;
    firstCascade: UniformNode<'uint', number>;
    screenSize: UniformNode<'vec2', Vector2>;
    shadowMapTexelSize: UniformNode<'vec2', Vector2>;
    shadowCascadeArray: UniformArrayNode;
    shadowMatrixArray: UniformArrayNode;
    private readonly textureNode;
    private readonly renderTarget;
    private readonly material;
    private readonly mesh;
    private rendererState?;
    constructor();
    getTextureNode(): TextureNode;
    update({ renderer }: NodeFrame): void;
    private setupFragmentNode;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
