import { Camera, Vector2 } from 'three';
import { NodeBuilder, NodeFrame, TextureNode, UniformNode } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class CoordinateNode extends Node {
    static get type(): string;
    viewZUnitNode: TextureNode;
    sliceEndpointsNode: TextureNode;
    camera: Camera;
    epipolarSliceCount: UniformNode<'float', number>;
    maxSliceSampleCount: UniformNode<'float', number>;
    screenSize: UniformNode<'vec2', Vector2>;
    private readonly textureNode;
    private readonly renderTarget;
    private readonly material;
    private readonly mesh;
    private rendererState?;
    constructor();
    getTextureNode(): TextureNode;
    update({ renderer }: NodeFrame): void;
    private setupFragmentNode;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
