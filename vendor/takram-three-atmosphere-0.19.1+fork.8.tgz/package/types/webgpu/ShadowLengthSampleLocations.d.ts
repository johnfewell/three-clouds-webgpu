import { Points } from 'three';
import { NodeMaterial } from 'three/webgpu';
import { ShadowLengthNode } from './ShadowLengthNode';
export declare class ShadowLengthSampleLocations extends Points {
    material: NodeMaterial;
    constructor(shadowLengthNode: ShadowLengthNode);
    dispose(): void;
}
