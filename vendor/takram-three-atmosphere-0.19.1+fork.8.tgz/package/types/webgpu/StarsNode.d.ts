import { Vector2 } from 'three';
import { TempNode, NodeBuilder, NodeFrame, TextureNode } from 'three/webgpu';
export declare class StarsNode extends TempNode {
    static get type(): string;
    readonly data: string | ArrayBufferLike;
    private dataPromise?;
    pointSize: import('three/webgpu').UniformNode<'float', number>;
    intensity: import('three/webgpu').UniformNode<'float', number>;
    magnitudeRange: import('three/webgpu').UniformNode<'vec2', Vector2>;
    private readonly textureNode;
    private readonly renderTarget;
    private readonly material;
    private readonly points;
    private camera?;
    private rendererState?;
    private positionBuffer?;
    private magnitudeBuffer?;
    private colorBuffer?;
    constructor(data?: string | ArrayBufferLike);
    getTextureNode(): TextureNode;
    setSize(width: number, height: number): this;
    updateBefore(frame: NodeFrame): void;
    private createBuffers;
    private setupMaterial;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
