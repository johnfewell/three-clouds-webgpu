export declare const viewZUnit: import('three/webgpu').VarNode;
