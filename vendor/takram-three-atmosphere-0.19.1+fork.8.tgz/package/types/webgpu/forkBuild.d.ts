export declare const forkBuild: {
    readonly release: 8;
    readonly r186Kernels: true;
};
