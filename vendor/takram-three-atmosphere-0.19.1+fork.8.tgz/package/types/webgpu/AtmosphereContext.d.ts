import { Vector2, Vector3, Camera } from 'three';
import { NodeBuilder } from 'three/webgpu';
import { Ellipsoid } from '@takram/three-geospatial';
import { AtmosphereContextBase } from './AtmosphereContextBase';
import { AtmosphereLUTNode } from './AtmosphereLUTNode';
import { AtmosphereParameters } from './AtmosphereParameters';
export declare class AtmosphereContext extends AtmosphereContextBase {
    lutNode: AtmosphereLUTNode;
    matrixWorldToECEF: import('three/webgpu').UniformNode<'mat4', import('three').Matrix4>;
    matrixECIToECEF: import('three/webgpu').UniformNode<'mat4', import('three').Matrix4>;
    sunDirectionECEF: import('three/webgpu').UniformNode<'vec3', Vector3>;
    moonDirectionECEF: import('three/webgpu').UniformNode<'vec3', Vector3>;
    matrixMoonFixedToECEF: import('three/webgpu').UniformNode<'mat4', import('three').Matrix4>;
    scatteringSampleCount: import('three/webgpu').UniformNode<'vec2', Vector2>;
    matrixECEFToWorld: import('three/webgpu').UniformNode<'mat4', import('three').Matrix4>;
    cameraPositionECEF: import('three/webgpu').UniformNode<'vec3', Vector3>;
    altitudeCorrectionECEF: import('three/webgpu').UniformNode<'vec3', Vector3>;
    cameraHeight: import('three/webgpu').UniformNode<'float', number>;
    cameraPositionUnit: import('three/webgpu').VarNode;
    altitudeCorrectionUnit: import('three/webgpu').VarNode;
    camera?: Camera;
    ellipsoid: Ellipsoid;
    correctAltitude: boolean;
    constrainCamera: boolean;
    showGround: boolean;
    accurateShadowScattering: boolean;
    raymarchScattering: boolean;
    lookupGroundLift: number;
    constructor(parameters?: AtmosphereParameters, lutNode?: AtmosphereLUTNode);
    dispose(): void;
}
/** @deprecated Use AtmosphereContext instead. */
export declare const AtmosphereContextNode: typeof AtmosphereContext;
export declare function getAtmosphereContext(builder: NodeBuilder): AtmosphereContext;
