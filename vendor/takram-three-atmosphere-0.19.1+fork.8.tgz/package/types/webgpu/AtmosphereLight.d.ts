import { DirectionalLight } from 'three';
export type AtmosphereLightBody = 'sun' | 'moon';
export declare class AtmosphereLight extends DirectionalLight {
    readonly type = "AtmosphereLight";
    distance: number;
    body: AtmosphereLightBody;
    direct: import('three/webgpu').UniformNode<'bool', false> | import('three/webgpu').UniformNode<'bool', true>;
    indirect: import('three/webgpu').UniformNode<'bool', false> | import('three/webgpu').UniformNode<'bool', true>;
    constructor(distance?: number, body?: AtmosphereLightBody);
}
