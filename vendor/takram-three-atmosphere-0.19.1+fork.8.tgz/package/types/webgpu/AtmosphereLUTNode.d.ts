import { Node, NodeBuilder, NodeFrame, Renderer, Texture3DNode, TextureNode } from 'three/webgpu';
import { AnyFloatType } from '@takram/three-geospatial';
import { AtmosphereParameters } from './AtmosphereParameters';
export type AtmosphereLUTTextureName = 'transmittance' | 'multipleScattering' | 'irradiance';
export type AtmosphereLUTTexture3DName = 'scattering' | 'singleMieScattering' | 'higherOrderScattering';
export declare class AtmosphereLUTNode extends Node {
    static get type(): string;
    parameters: AtmosphereParameters;
    textureType?: AnyFloatType;
    private textures?;
    private readonly textureNodes;
    private currentVersion?;
    private updating;
    private disposeQueue;
    constructor(parameters?: AtmosphereParameters, textureType?: AnyFloatType);
    getTextureNode(name: AtmosphereLUTTextureName): TextureNode;
    getTextureNode(name: AtmosphereLUTTexture3DName): Texture3DNode;
    private dispatchUpdate;
    private performCompute;
    updateTextures(renderer: Renderer): Promise<void>;
    updateBefore({ renderer }: NodeFrame): void;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
}
