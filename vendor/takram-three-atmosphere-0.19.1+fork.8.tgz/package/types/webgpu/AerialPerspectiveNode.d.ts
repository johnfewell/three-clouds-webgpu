import { TempNode, NodeBuilder } from 'three/webgpu';
import { Node } from '@takram/three-geospatial/webgpu';
export declare class AerialPerspectiveNode extends TempNode {
    static get type(): string;
    colorNode: Node<'vec4'>;
    depthNode: Node<'float'>;
    normalNode?: Node<'vec3'> | null;
    skyNode?: Node<'vec3'> | null;
    shadowLengthNode?: Node<'vec2'> | null;
    shadowNode: Node<'float'> | null;
    lightingMaskNode: Node<'float'> | null;
    correctGeometricError: boolean;
    lighting: boolean;
    transmittance: boolean;
    inscattering: boolean;
    moonScattering: boolean;
    constructor(colorNode: Node<'vec4'>, depthNode: Node<'float'>, normalNode?: Node<'vec3'> | null, shadowLengthNode?: Node<'vec2'> | null);
    customCacheKey(): number;
    setup(builder: NodeBuilder): unknown;
    dispose(): void;
    /** @deprecated Use inscattering instead. */
    get inscatter(): boolean;
    /** @deprecated Use inscattering instead. */
    set inscatter(value: boolean);
}
export declare const aerialPerspective: (...args: ConstructorParameters<typeof AerialPerspectiveNode>) => AerialPerspectiveNode;
