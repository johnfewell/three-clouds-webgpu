import { BufferGeometry } from 'three';
export declare class StarsGeometry extends BufferGeometry {
    constructor(data: ArrayBuffer);
}
